CONTAINER HOME — META QUEST 2 WALKTHROUGH
========================================

This is a conceptual WebXR walkthrough of the container/block home we designed.

IMPORTANT:
- The model is NOT construction-ready.
- Dimensions and structural geometry are approximate.
- It is intended for design visualization only.

HOW TO USE ON META QUEST 2
1. Put index.html on an HTTPS web host.
2. On the Quest 2, open Meta Quest Browser.
3. Open the HTTPS address for the page.
4. Press "Enter VR".
5. Use the controller thumbstick to move and look around.
6. Look at a blue floor marker and select it to jump to another viewpoint.

The page uses A-Frame from a public CDN, so the Quest needs internet access.

A simple hosting route is GitHub Pages, Netlify, Vercel, or another HTTPS static host.

DESIGN BASIS
- Four 40-ft containers, two side-by-side per bedroom wing.
- Recessed concrete-block center.
- Centered main entrance.
- Gabled central roof.
- Open living/dining/kitchen.
- Laundry near kitchen with separate outside access.
- Two bedrooms and compact shared bathroom on left.
- Master bedroom, ensuite and small patio on right.
- Fixed glass openings at container fronts.
- Conceptual rear terrace / optional pool area.
